-- =========================================================================
-- DATABASE BLUEPRINT: SIG-TAR MAMASA (SISTEM INFORMASI GEOGRAFIS TATA RUANG)
-- Server Target: cPanel Online (MySQL 8.0+ / MariaDB 10.5+)
-- Karakteristik: Native Spatial Engine, Zero-dependency, Fast Execution
-- =========================================================================

CREATE DATABASE IF NOT EXISTS `sig_tar_mamasa` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `sig_tar_mamasa`;

-- 1. TABEL PENGGUNA & HAK AKSES (RBAC)
CREATE TABLE IF NOT EXISTS `users` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `nama` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('super_admin', 'planner_bappeda', 'validator_pupr', 'editor_bpbd', 'eksekutif_bupati', 'public_viewer') NOT NULL DEFAULT 'public_viewer',
    `instansi` VARCHAR(100) NOT NULL DEFAULT 'Masyarakat Umum',
    `status_aktif` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. TABEL BATAS WILAYAH ADMINISTRASI DESA/KECAMATAN
CREATE TABLE IF NOT EXISTS `regions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `kode_wilayah` VARCHAR(20) NOT NULL UNIQUE,
    `kecamatan` VARCHAR(100) NOT NULL,
    `desa` VARCHAR(100) NOT NULL,
    `kategori` VARCHAR(50) DEFAULT 'Pedesaan',
    `jumlah_penduduk` INT UNSIGNED NOT NULL DEFAULT 0,
    `kepadatan_jiwa_km2` INT UNSIGNED NOT NULL DEFAULT 0,
    `luas_km2` DECIMAL(8,2) NOT NULL DEFAULT 0.00,
    `puskesmas_terdekat` VARCHAR(150) NULL,
    `jarak_puskesmas_km` DECIMAL(5,2) DEFAULT 0.00,
    `geom` GEOMETRY NOT NULL /*!80003 SRID 4326 */,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    SPATIAL INDEX(`geom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. TABEL ZONASI KERAWANAN BENCANA (SAFETY FILTER)
CREATE TABLE IF NOT EXISTS `disaster_hazard_zones` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `kode_zona` VARCHAR(30) NOT NULL UNIQUE,
    `tipe_bencana` VARCHAR(100) NOT NULL,
    `tingkat_kerawanan` ENUM('merah', 'kuning', 'hijau') NOT NULL,
    `label` VARCHAR(150) NOT NULL,
    `kemiringan_lereng` VARCHAR(100) NOT NULL,
    `jenis_tanah` VARCHAR(100) NOT NULL,
    `curah_hujan_tahunan` VARCHAR(50) NOT NULL,
    `rekomendasi_tataruang` TEXT NOT NULL,
    `color_hex` VARCHAR(10) NOT NULL DEFAULT '#ef4444',
    `geom` GEOMETRY NOT NULL /*!80003 SRID 4326 */,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    SPATIAL INDEX(`geom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. TABEL FASILITAS PUBLIK (SMART ALLOCATION)
CREATE TABLE IF NOT EXISTS `public_facilities` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `kode_fasilitas` VARCHAR(30) NOT NULL UNIQUE,
    `nama` VARCHAR(150) NOT NULL,
    `kategori` ENUM('Kesehatan', 'Pendidikan', 'Pemerintahan', 'Ekonomi & Publik') NOT NULL,
    `sub_kategori` VARCHAR(100) NOT NULL,
    `kapasitas` VARCHAR(100) NOT NULL,
    `tenaga_medis` INT UNSIGNED DEFAULT 0,
    `radius_layanan_km` INT UNSIGNED NOT NULL DEFAULT 5,
    `alamat` VARCHAR(255) NOT NULL,
    `status_operasional` VARCHAR(50) DEFAULT 'Aktif',
    `location` POINT NOT NULL /*!80003 SRID 4326 */,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    SPATIAL INDEX(`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. TABEL SENTRA EKONOMI & UMKM (ECONOMIC HUB)
CREATE TABLE IF NOT EXISTS `economic_hubs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `kode_hub` VARCHAR(30) NOT NULL UNIQUE,
    `nama` VARCHAR(150) NOT NULL,
    `sektor` VARCHAR(100) NOT NULL,
    `komoditas` VARCHAR(150) NOT NULL,
    `kapasitas_ton_tahun` DECIMAL(10,2) DEFAULT 0.00,
    `jumlah_pelaku_usaha` INT UNSIGNED DEFAULT 0,
    `status_sertifikasi` VARCHAR(100) NULL,
    `jarak_ke_jalan_provinsi_km` DECIMAL(5,2) DEFAULT 0.00,
    `rekomendasi_logistik` TEXT NULL,
    `location` POINT NOT NULL /*!80003 SRID 4326 */,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    SPATIAL INDEX(`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. TABEL LOG SCREENING KOORDINAT & PERIZINAN TATA RUANG (SAFETY FILTER PERMIT)
CREATE TABLE IF NOT EXISTS `spatial_screenings` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `nomor_registrasi` VARCHAR(60) NOT NULL UNIQUE,
    `nama_pemohon` VARCHAR(150) NOT NULL,
    `nama_proyek` VARCHAR(200) NOT NULL,
    `jenis_kegiatan` VARCHAR(100) NOT NULL,
    `latitude` DECIMAL(10, 7) NOT NULL,
    `longitude` DECIMAL(10, 7) NOT NULL,
    `coordinate` POINT NOT NULL /*!80003 SRID 4326 */,
    `hasil_zona` ENUM('merah', 'kuning', 'hijau') NOT NULL,
    `status_rekomendasi` ENUM('DITOLAK_BAHAYA', 'DISETUJUI_BERSYARAT', 'DISETUJUI_AMAN') NOT NULL,
    `titik_alternatif_lat` DECIMAL(10, 7) NULL,
    `titik_alternatif_lng` DECIMAL(10, 7) NULL,
    `jarak_titik_alternatif_meter` INT UNSIGNED NULL,
    `catatan_teknis` TEXT NULL,
    `validator_user_id` BIGINT UNSIGNED NULL,
    `validator_nama` VARCHAR(100) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    SPATIAL INDEX(`coordinate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =========================================================================
-- DATA DEFAULT SEEDER (USER RBAC & INITIAL CONFIG)
-- =========================================================================
INSERT INTO `users` (`nama`, `email`, `password`, `role`, `instansi`) VALUES
('Administrator Utama', 'admin@mamasa.go.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'super_admin', 'Diskominfo Mamasa'),
('Tim Perencana Ruang', 'planner@bappeda.mamasa.go.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'planner_bappeda', 'BAPPEDA Mamasa'),
('Validator Izin Tata Ruang', 'validator@pupr.mamasa.go.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'validator_pupr', 'Dinas PUPR Mamasa'),
('Pusdalops Kebencanaan', 'bpbd@mamasa.go.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'editor_bpbd', 'BPBD Kab. Mamasa'),
('Bupati / Eksekutif', 'bupati@mamasa.go.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'eksekutif_bupati', 'Pemerintah Daerah Kab. Mamasa');
