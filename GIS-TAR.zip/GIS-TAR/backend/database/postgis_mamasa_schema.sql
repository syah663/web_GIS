-- =========================================================================
-- DATABASE BLUEPRINT POSTGRESQL + POSTGIS: SIG-TAR MAMASA (REV-2.0)
-- Skala Skripsi S1: Fokus Studi Kasus Kecamatan Mamasa & Integrasi Gemini API
-- =========================================================================

-- Aktifkan Ekstensi PostGIS
CREATE EXTENSION IF NOT EXISTS postgis;

-- 1. TABEL BATAS ADMINISTRASI DESA KECAMATAN MAMASA
CREATE TABLE IF NOT EXISTS villages (
    id SERIAL PRIMARY KEY,
    kode_desa VARCHAR(20) NOT NULL UNIQUE,
    nama_desa VARCHAR(100) NOT NULL,
    kecamatan VARCHAR(50) DEFAULT 'Mamasa',
    tipe_wilayah VARCHAR(80),
    jumlah_penduduk INT DEFAULT 0,
    kepadatan_jiwa_km2 INT DEFAULT 0,
    luas_km2 NUMERIC(6,2) DEFAULT 0.00,
    puskesmas_terdekat VARCHAR(100),
    jarak_puskesmas_km NUMERIC(5,2),
    geom GEOMETRY(Polygon, 4326) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_villages_geom ON villages USING GIST (geom);

-- 2. TABEL ZONA RISIKO BENCANA MIKRO KECAMATAN MAMASA
CREATE TABLE IF NOT EXISTS hazard_zones (
    id SERIAL PRIMARY KEY,
    kode_zona VARCHAR(30) NOT NULL UNIQUE,
    tipe_bencana VARCHAR(100) NOT NULL, -- Longsor Tebing, Banjir Sungai, Gerakan Tanah
    tingkat_kerawanan VARCHAR(20) NOT NULL, -- merah, kuning, hijau
    label VARCHAR(150) NOT NULL,
    kemiringan_lereng VARCHAR(50),
    jenis_tanah VARCHAR(80),
    curah_hujan_tahunan VARCHAR(50),
    rekomendasi_tataruang TEXT NOT NULL,
    geom GEOMETRY(Polygon, 4326) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_hazard_zones_geom ON hazard_zones USING GIST (geom);

-- 3. TABEL FASILITAS PUBLIK EKSISTING KECAMATAN MAMASA
CREATE TABLE IF NOT EXISTS public_facilities (
    id SERIAL PRIMARY KEY,
    nama_fasilitas VARCHAR(150) NOT NULL,
    kategori VARCHAR(50) NOT NULL, -- Kesehatan, Pendidikan, Pemerintahan
    sub_kategori VARCHAR(80),
    kapasitas VARCHAR(100),
    radius_spm_km NUMERIC(4,1) DEFAULT 3.0,
    geom GEOMETRY(Point, 4326) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_facilities_geom ON public_facilities USING GIST (geom);

-- 4. TABEL LOG SCREENING SPASIAL & NARASI GEMINI AI
CREATE TABLE IF NOT EXISTS ai_spatial_evaluations (
    id SERIAL PRIMARY KEY,
    nomor_registrasi VARCHAR(60) NOT NULL UNIQUE,
    modul_evaluasi VARCHAR(50) NOT NULL, -- 'smart_allocation' atau 'safety_filter'
    nama_kegiatan VARCHAR(200) NOT NULL,
    pemohon VARCHAR(150),
    latitude NUMERIC(10, 7) NOT NULL,
    longitude NUMERIC(10, 7) NOT NULL,
    hasil_zona VARCHAR(20), -- merah, kuning, hijau
    jarak_ke_fasilitas_m INT,
    populasi_terlayani INT,
    status_rekomendasi VARCHAR(50) NOT NULL, -- 'DITOLAK_BAHAYA', 'DISETUJUI_BERSYARAT', 'DISETUJUI_AMAN'
    titik_alternatif_lat NUMERIC(10, 7),
    titik_alternatif_lng NUMERIC(10, 7),
    jarak_alternatif_m INT,
    gemini_prompt TEXT NOT NULL,
    gemini_narrative_output TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================================================================
-- CONTOH FUNGSI QUERY SPASIAL POSTGIS UNTUK LARAVEL BACKEND
-- =========================================================================

-- Query 1 (Safety Filter Intersect): Cek apakah titik koordinat berada di Zona Bahaya
-- SELECT h.tingkat_kerawanan, h.label, h.kemiringan_lereng, h.rekomendasi_tataruang
-- FROM hazard_zones h
-- WHERE ST_Intersects(h.geom, ST_SetSRID(ST_Point(119.390, -2.955), 4326))
-- LIMIT 1;

-- Query 2 (Titik Alternatif Terdekat di Zona Hijau):
-- SELECT ST_Y(ST_Centroid(geom)) as lat, ST_X(ST_Centroid(geom)) as lng,
--        ROUND(ST_Distance(geom::geography, ST_SetSRID(ST_Point(119.390, -2.955), 4326)::geography)) as jarak_meter
-- FROM hazard_zones
-- WHERE tingkat_kerawanan = 'hijau'
-- ORDER BY geom <-> ST_SetSRID(ST_Point(119.390, -2.955), 4326)
-- LIMIT 1;

-- Query 3 (Smart Allocation Distance): Jarak titik usulan ke Fasilitas Kesehatan terdekat
-- SELECT p.nama_fasilitas, ROUND(ST_Distance(p.geom::geography, ST_SetSRID(ST_Point(119.340, -2.960), 4326)::geography) / 1000.0, 2) as jarak_km
-- FROM public_facilities p
-- WHERE p.kategori = 'Kesehatan'
-- ORDER BY p.geom <-> ST_SetSRID(ST_Point(119.340, -2.960), 4326)
-- LIMIT 1;
