<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\GeminiReasoningService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SpatialReasoningController extends Controller
{
    protected GeminiReasoningService $geminiService;

    public function __construct(GeminiReasoningService $geminiService)
    {
        $this->geminiService = $geminiService;
    }

    /**
     * Endpoint Evaluasi Spasial Terpadu + Penalaran Naratif Gemini AI
     * POST /api/spatial-evaluate
     */
    public function evaluate(Request $request)
    {
        $request->validate([
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
            'module' => 'required|in:smart_allocation,safety_filter',
            'nama_proyek' => 'nullable|string',
            'nama_pemohon' => 'nullable|string'
        ]);

        $lat = (float) $request->input('latitude');
        $lng = (float) $request->input('longitude');
        $module = $request->input('module');

        if ($module === 'safety_filter') {
            return $this->handleSafetyFilter($lat, $lng, $request->all());
        } else {
            return $this->handleSmartAllocation($lat, $lng, $request->all());
        }
    }

    protected function handleSafetyFilter(float $lat, float $lng, array $payload)
    {
        // Default micro reference coordinates for Kecamatan Mamasa
        // Red hazard zone: Poros Tebing Barat & Lereng Rambusaratu-Lambanan
        // Green zone center: Lembah Aluvial Mamasa (-2.952, 119.365)
        $isRed = ($lat < -2.940 && $lat > -2.975 && $lng > 119.378);
        $isYellow = ($lat < -2.960 && $lng < 119.340);
        
        $zona = $isRed ? 'merah' : ($isYellow ? 'kuning' : 'hijau');
        $status = $isRed ? 'DITOLAK_BAHAYA' : ($isYellow ? 'DISETUJUI_BERSYARAT' : 'DISETUJUI_AMAN');

        $altLat = -2.952000;
        $altLng = 119.365000;
        $jarakAltMeter = $isRed ? 420 : 0;

        $spatialData = [
            'lat' => $lat,
            'lng' => $lng,
            'zona' => $zona,
            'status_rekomendasi' => $status,
            'kemiringan' => $isRed ? '> 42%' : ($isYellow ? '22%' : '8%'),
            'tipe_lereng' => $isRed ? 'Lereng Sangat Curam Rawan Longsor' : ($isYellow ? 'Lereng Sedang' : 'Dataran Lembah Landai'),
            'alt_lat' => $altLat,
            'alt_lng' => $altLng,
            'jarak_alt_meter' => $jarakAltMeter,
            'arah_mata_angin' => 'Barat Laut (Lembah Kota Mamasa)',
            'nama_proyek' => $payload['nama_proyek'] ?? 'Bangunan Gedung / Komersial',
            'nama_pemohon' => $payload['nama_pemohon'] ?? 'Pemohon Terdaftar'
        ];

        // Call Gemini Narrative Reasoning
        $narrative = $this->geminiService->generateSafetyFilterReasoning($spatialData);

        return response()->json([
            'success' => true,
            'module' => 'safety_filter',
            'data' => array_merge($spatialData, [
                'ai_reasoning_narrative' => $narrative,
                'is_locked' => ($zona === 'merah')
            ])
        ]);
    }

    protected function handleSmartAllocation(float $lat, float $lng, array $payload)
    {
        // Calculate distance to nearest PKM in Kecamatan Mamasa
        // Puskesmas Mamasa Kota: [-2.946, 119.356]
        $pkmLat = -2.946;
        $pkmLng = 119.356;
        
        // Approximate distance calculation
        $dLat = deg2rad($lat - $pkmLat);
        $dLng = deg2rad($lng - $pkmLng);
        $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($pkmLat)) * cos(deg2rad($lat)) * sin($dLng/2) * sin($dLng/2);
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        $jarakKm = round(6371 * $c, 2);

        $isBlankSpot = ($jarakKm > 3.0);
        $populasi = ($jarakKm > 3.0) ? 2450 : 1200;

        $spatialData = [
            'lat' => $lat,
            'lng' => $lng,
            'nama_fasilitas' => $payload['nama_fasilitas'] ?? 'Puskesmas Pembantu (Pustu)',
            'desa' => 'Desa Lambanan (Kec. Mamasa)',
            'jarak_km' => $jarakKm,
            'is_blank_spot' => $isBlankSpot,
            'populasi' => $populasi
        ];

        // Call Gemini Narrative Reasoning
        $narrative = $this->geminiService->generateSmartAllocationReasoning($spatialData);

        return response()->json([
            'success' => true,
            'module' => 'smart_allocation',
            'data' => array_merge($spatialData, [
                'ai_reasoning_narrative' => $narrative
            ])
        ]);
    }
}
