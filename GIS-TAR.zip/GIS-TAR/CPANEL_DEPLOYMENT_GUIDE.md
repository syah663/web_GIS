# PANDUAN DEPLOYMENT SIG-TAR MAMASA KE SERVER ONLINE cPanel

Panduan ini disusun khusus untuk tim teknis Diskominfo / BAPPEDA / PUPR Kabupaten Mamasa dalam melakukan instalasi dan peluncuran **SIG-TAR Mamasa** pada server online berbasis **cPanel**.

---

## 📁 Ringkasan Struktur Berkas Siap Deploy

```text
GIS-TAR/
├── index.html                           # WebGIS Production Standalone (Siap Dobel Klik / Upload)
├── public_html/
│   └── index.html                       # Berkas WebGIS utama untuk root public_html cPanel
├── backend/
│   ├── api/
│   │   ├── screen.php                   # Endpoint screening koordinat & verifikasi zona
│   │   └── stats.php                    # Endpoint statistik dasbor eksekutif
│   ├── config/
│   │   └── database.php                 # Konfigurasi koneksi MySQL cPanel
│   └── database/
│       └── sig_tar_mamasa_schema.sql    # Skema DDL & Seeder Spatial MySQL 8.0+
├── data-assets/                         # Master dataset GeoJSON Kabupaten Mamasa
│   ├── mamasa_boundaries.json           # Batas wilayah desa & kecamatan
│   ├── hazard_zones.json                # Peta zonasi kerawanan longsor (Merah/Kuning/Hijau)
│   ├── public_facilities.json           # Titik RSUD, Puskesmas, Sekolah & Kantor
│   └── economic_hubs.json               # Sentra UMKM Kopi, Tenun & Koridor Jalan
└── frontend/                            # Sumber kode Vite + React + Leaflet + Tailwind
```

---

## 🚀 Langkah 1: Persiapan Database MySQL di cPanel

1. Masuk ke dashboard cPanel Anda (contoh: `https://namadomain.mamasa.go.id:2083`).
2. Buka menu **MySQL Databases**:
   * Buat basis data baru, misalnya: `namacpanel_sigtar`.
   * Buat pengguna MySQL baru, misalnya: `namacpanel_gisuser` beserta kata sandi yang kuat.
   * Hubungkan pengguna ke database dengan memberikan centang pada **ALL PRIVILEGES**.
3. Buka menu **phpMyAdmin** di cPanel:
   * Pilih database `namacpanel_sigtar`.
   * Klik tab **Import**, lalu pilih berkas `backend/database/sig_tar_mamasa_schema.sql`.
   * Klik **Go / Kirim** untuk mengeksekusi pembuatan tabel spasial dan data default.

---

## ⚙️ Langkah 2: Konfigurasi Koneksi Database Backend

Buka berkas `backend/config/database.php` dan sesuaikan kredensial database Anda:

```php
$db_host = 'localhost';
$db_name = 'namacpanel_sigtar';      // Nama database cPanel Anda
$db_user = 'namacpanel_gisuser';     // Username MySQL cPanel Anda
$db_pass = 'PasswordKuatAnda123!';   // Password MySQL cPanel Anda
```

---

## 🌐 Langkah 3: Upload Berkas Web ke File Manager cPanel

1. Di dashboard cPanel, buka **File Manager** dan masuk ke direktori `public_html`.
2. Unggah seluruh isi berkas dari folder proyek:
   * Letakkan berkas `public_html/index.html` langsung di dalam folder `public_html` (root website).
   * Buat folder `api/` di dalam `public_html/` dan unggah `backend/api/screen.php` serta `backend/api/stats.php`.
   * Buat folder `config/` dan unggah `backend/config/database.php`.
3. Pastikan izin akses berkas (*file permissions*) berstatus `644` untuk file dan `755` untuk direktori.

---

## 🔒 Langkah 4: Aktivasi Enkripsi HTTPS (SSL/TLS)

Sesuai persyaratan non-fungsional PRD (pertukaran data koordinat wajib terenkripsi):
1. Buka menu **SSL/TLS Status** di cPanel.
2. Pilih domain Anda, lalu klik tombol **Run AutoSSL** (atau install Let's Encrypt SSL gratis).
3. Pastikan domain dapat diakses dengan protokol aman: `https://namadomain.mamasa.go.id`.

---

## ✅ Langkah 5: Pengujian & Verifikasi 4 Modul di Server Online

1. **Modul 1 (Smart Allocation):**
   * Buka menu *Smart Allocation*, geser slider buffer dari 2 km ke 5 km dan 12 km.
   * Pastikan lingkaran jangkauan Puskesmas berubah secara dinamis dan daftar desa blank spot (Pana, Nosu, Tabang) terdeteksi.
   * Klik tombol *Mulai Simulasi Titik Baru* lalu klik pada area blank spot, pastikan persentase cakupan melonjak naik.

2. **Modul 2 (Safety Filter):**
   * Buka menu *Safety Filter*, klik lokasi lereng tebing pegunungan (Zona Merah).
   * Verifikasi bahwa:
     * Muncul banner merah berkedip bertuliskan **PERINGATAN KERAS: ZONA MERAH**.
     * Tombol *Rekomendasikan Izin* **terkunci otomatis**.
     * Sistem menampilkan kotak rekomendasi **Titik Alternatif Zona Hijau Terdekat** beserta jaraknya.
   * Klik tombol *Pindahkan Titik Proyek ke Zona Hijau Terdekat*, tombol perizinan akan terbuka menjadi hijau dan dapat disimpan.

3. **Modul 3 (Economic Hub):**
   * Buka tab *Economic Hub*, verifikasi sebaran titik Sentra Kopi Arabika Gandangbatu, Mambulilling, dan Tenun Mamasa.
   * Klik *Fokuskan Titik Logistik*, peta otomatis melakukan zoom halus ke Rencana Kawasan Logistik Hub Sumarorong.

4. **Modul 4 (Executive Dashboard & Cetak Dokumen PDF):**
   * Klik tombol *Cetak PDF* pada hasil screening atau dari log dasbor eksekutif.
   * Dokumen berformat resmi Pemkab Mamasa (lengkap dengan kop surat, status zona bencana, catatan teknis, dan verifikasi tanda tangan digital) akan tampil dan siap disimpan ke format PDF atau dicetak ke printer fisik.
