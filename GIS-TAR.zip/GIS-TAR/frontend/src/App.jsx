import React, { useState } from 'react';
import Navbar from './components/Navbar';
import MapContainer from './components/MapContainer';
import LayerControlPanel from './components/LayerControlPanel';
import SmartAllocationPanel from './components/SmartAllocationPanel';
import SafetyFilterModal from './components/SafetyFilterModal';
import EconomicHubPanel from './components/EconomicHubPanel';
import ExecutiveDashboardModal from './components/ExecutiveDashboardModal';
import PrintRecommendationDoc from './components/PrintRecommendationDoc';
import * as turf from '@turf/turf';
import { hazardZones } from './data/spatialData';

export default function App() {
  // Dual Portal & RBAC State
  const [currentMode, setCurrentMode] = useState('internal'); // 'public' or 'internal'
  const [currentRole, setCurrentRole] = useState('bappeda'); // 'bappeda', 'pupr', 'bpbd', 'bupati'

  // Active UI Module Window
  const [activeModule, setActiveModule] = useState('safety'); // 'allocation', 'safety', 'economic', 'executive', or null

  // Map Basemap & Layers
  const [currentTile, setCurrentTile] = useState('cartoDark');
  const [activeLayers, setActiveLayers] = useState({
    boundaries: true,
    demographyHeat: false,
    hazard: true,
    facilities: true,
    economic: true,
    roads: true
  });

  // Module 1 (Smart Allocation) State
  const [bufferRadiusKm, setBufferRadiusKm] = useState(5);
  const [isSimulatingNewFacility, setIsSimulatingNewFacility] = useState(false);
  const [simulatedPoint, setSimulatedPoint] = useState(null);

  // Module 2 (Safety Filter) State
  const [isPickingLocation, setIsPickingLocation] = useState(false);
  const [screeningPoint, setScreeningPoint] = useState({ lat: -2.955, lng: 119.390 });
  const [screeningResult, setScreeningResult] = useState({
    lat: -2.955,
    lng: 119.390,
    zone: 'merah',
    status: 'DITOLAK_BAHAYA',
    featureInfo: {
      label: 'Zona Merah (Sangat Rawan Longsor)',
      kemiringan_lereng: '> 45% (Sangat Curam)',
      rekomendasi_tataruang: 'DILARANG KERAS UNTUK PEMBANGUNAN FISIK/PEMUKIMAN. Wajib fungsi lindung dan reboisasi.'
    },
    alternativePoint: { lat: -2.952, lng: 119.365 },
    distanceToSafe: 2800
  });

  // Module 3 (Economic Hub) State
  const [selectedHub, setSelectedHub] = useState(null);

  // Module 4 (Executive & Document Print) State
  const [showDocModal, setShowDocModal] = useState(false);
  const [selectedScreeningForDoc, setSelectedScreeningForDoc] = useState(null);

  // Toggle active layer
  const toggleLayer = (layerName) => {
    setActiveLayers((prev) => ({
      ...prev,
      [layerName]: !prev[layerName]
    }));
  };

  // Evaluate Coordinates when user clicks on the map
  const handleMapClickCoordinates = (latlng) => {
    const lat = latlng.lat;
    const lng = latlng.lng;

    // If in simulation mode (Module 1)
    if (isSimulatingNewFacility) {
      setSimulatedPoint({ lat, lng });
      setIsSimulatingNewFacility(false);
      return;
    }

    // If in coordinate picking mode or safety filter open (Module 2)
    if (isPickingLocation || activeModule === 'safety') {
      const pt = turf.point([lng, lat]);
      let detectedZone = 'hijau';
      let matchedFeature = null;

      for (const feature of hazardZones.features) {
        if (feature.geometry.type === 'Polygon') {
          const poly = turf.polygon(feature.geometry.coordinates);
          if (turf.booleanPointInPolygon(pt, poly)) {
            detectedZone = feature.properties.tingkat_kerawanan;
            matchedFeature = feature;
            break;
          }
        }
      }

      let status = 'DISETUJUI_AMAN';
      let alternativePoint = null;
      let distanceToSafe = 0;

      if (detectedZone === 'merah') {
        status = 'DITOLAK_BAHAYA';
        const greenSafeLng = 119.365;
        const greenSafeLat = -2.952;
        alternativePoint = { lat: greenSafeLat, lng: greenSafeLng };
        const safePt = turf.point([greenSafeLng, greenSafeLat]);
        distanceToSafe = Math.round(turf.distance(pt, safePt, { units: 'kilometers' }) * 1000);
      } else if (detectedZone === 'kuning') {
        status = 'DISETUJUI_BERSYARAT';
      }

      const result = {
        lat,
        lng,
        zone: detectedZone,
        status,
        featureInfo: matchedFeature ? matchedFeature.properties : {
          label: 'Zona Hijau (Lembah Aman)',
          kemiringan_lereng: '< 15% (Landai)',
          rekomendasi_tataruang: 'DIREKOMENDASIKAN UNTUK PEMBANGUNAN GEDUNG/FASILITAS UMUM.'
        },
        alternativePoint,
        distanceToSafe
      };

      setScreeningPoint({ lat, lng });
      setScreeningResult(result);
      setIsPickingLocation(false);
    }
  };

  const handleOpenDocModal = () => {
    setSelectedScreeningForDoc({
      nomor_registrasi: 'REG-MMS-2026-001',
      nama_pemohon: 'PT. Sulawesi Agro Mandiri',
      nama_proyek: 'Pembangunan Fasilitas Pergudangan & Agrowisata',
      jenis_kegiatan: 'Komersial / Industri Ringan',
      latitude: screeningResult?.lat || -2.955,
      longitude: screeningResult?.lng || 119.390,
      hasil_zona: screeningResult?.zone || 'merah',
      status_rekomendasi: screeningResult?.status || 'DITOLAK_BAHAYA',
      titik_alternatif_lat: screeningResult?.alternativePoint?.lat,
      titik_alternatif_lng: screeningResult?.alternativePoint?.lng,
      jarak_titik_alternatif_meter: screeningResult?.distanceToSafe,
      catatan_teknis: screeningResult?.featureInfo?.rekomendasi_tataruang
    });
    setShowDocModal(true);
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-950 font-sans text-slate-100">
      {/* Top Navigation */}
      <Navbar
        currentMode={currentMode}
        setCurrentMode={setCurrentMode}
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
        activeModule={activeModule}
        setActiveModule={setActiveModule}
        activeLayers={activeLayers}
        setActiveLayers={setActiveLayers}
      />

      {/* Main Map Workspace Area */}
      <main className="flex-1 relative overflow-hidden">
        {/* Fullscreen Leaflet WebGIS */}
        <MapContainer
          currentTile={currentTile}
          activeLayers={activeLayers}
          bufferRadiusKm={bufferRadiusKm}
          screeningPoint={screeningPoint}
          screeningResult={screeningResult}
          isPickingLocation={isPickingLocation}
          onMapClickCoordinates={handleMapClickCoordinates}
          simulatedPoint={simulatedPoint}
          isSimulatingNewFacility={isSimulatingNewFacility}
          selectedHub={selectedHub}
        />

        {/* Floating Layer Control & Legend (Top-Right) */}
        <LayerControlPanel
          activeLayers={activeLayers}
          toggleLayer={toggleLayer}
          currentTile={currentTile}
          setCurrentTile={setCurrentTile}
          isPublicMode={currentMode === 'public'}
        />

        {/* Notification Banner when in Click/Picker Mode */}
        {(isPickingLocation || isSimulatingNewFacility) && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 px-5 py-2 rounded-full bg-amber-500 text-slate-950 font-bold text-xs shadow-2xl flex items-center gap-2 animate-bounce">
            <span>
              {isSimulatingNewFacility 
                ? '📍 Klik sembarang titik di peta untuk menempatkan fasilitas baru' 
                : '📍 Klik lokasi proyek pada peta untuk mengecek kerawanan longsor'}
            </span>
          </div>
        )}

        {/* MODULE 1: SMART ALLOCATION PANEL */}
        {activeModule === 'allocation' && (
          <SmartAllocationPanel
            onClose={() => setActiveModule(null)}
            bufferRadiusKm={bufferRadiusKm}
            setBufferRadiusKm={setBufferRadiusKm}
            isSimulatingNewFacility={isSimulatingNewFacility}
            setIsSimulatingNewFacility={setIsSimulatingNewFacility}
            simulatedPoint={simulatedPoint}
            setSimulatedPoint={setSimulatedPoint}
            onResetSimulation={() => setSimulatedPoint(null)}
          />
        )}

        {/* MODULE 2: SAFETY FILTER PANEL */}
        {activeModule === 'safety' && (
          <SafetyFilterModal
            onClose={() => setActiveModule(null)}
            screeningPoint={screeningPoint}
            setScreeningPoint={setScreeningPoint}
            screeningResult={screeningResult}
            setScreeningResult={setScreeningResult}
            onOpenDocModal={handleOpenDocModal}
            isPickingLocation={isPickingLocation}
            setIsPickingLocation={setIsPickingLocation}
          />
        )}

        {/* MODULE 3: ECONOMIC HUB PANEL */}
        {activeModule === 'economic' && (
          <EconomicHubPanel
            onClose={() => setActiveModule(null)}
            onSelectHub={setSelectedHub}
            selectedHub={selectedHub}
          />
        )}

        {/* MODULE 4: EXECUTIVE DASHBOARD MODAL */}
        {activeModule === 'executive' && (
          <ExecutiveDashboardModal
            onClose={() => setActiveModule(null)}
            onOpenDocModal={() => setShowDocModal(true)}
            setSelectedScreeningForDoc={setSelectedScreeningForDoc}
          />
        )}

        {/* PRINT RECOMMENDATION DECREE MODAL */}
        {showDocModal && (
          <PrintRecommendationDoc
            data={selectedScreeningForDoc}
            onClose={() => setShowDocModal(false)}
          />
        )}
      </main>
    </div>
  );
}
