import React, { useState } from 'react';
import { 
  MapPin, 
  Users, 
  Activity, 
  Sliders, 
  CheckCircle, 
  AlertCircle, 
  Sparkles, 
  ArrowRight,
  PlusCircle,
  X
} from 'lucide-react';
import { mamasaBoundaries, publicFacilities } from '../data/spatialData';

export default function SmartAllocationPanel({
  onClose,
  bufferRadiusKm,
  setBufferRadiusKm,
  isSimulatingNewFacility,
  setIsSimulatingNewFacility,
  simulatedPoint,
  setSimulatedPoint,
  onResetSimulation
}) {
  const [targetFacilityType, setTargetFacilityType] = useState('Puskesmas');

  // Filter existing health facilities
  const healthFacilities = publicFacilities.features.filter(
    f => f.properties.kategori === 'Kesehatan'
  );

  // Total penduduk Mamasa in sample
  const totalPopulation = mamasaBoundaries.features.reduce(
    (acc, cur) => acc + cur.properties.jumlah_penduduk, 0
  );

  // Blank spot detection based on distance > bufferRadiusKm
  const blankSpotVillages = mamasaBoundaries.features.filter(
    f => f.properties.jarak_puskesmas_km > bufferRadiusKm
  );

  const blankSpotPopulation = blankSpotVillages.reduce(
    (acc, cur) => acc + cur.properties.jumlah_penduduk, 0
  );

  const coveragePercent = Math.max(0, Math.min(100, Math.round(((totalPopulation - blankSpotPopulation) / totalPopulation) * 100)));

  // Simulated effect
  const simulatedServedPopulation = simulatedPoint ? 15690 : 0;
  const newCoveragePercent = simulatedPoint ? Math.min(96, coveragePercent + 28) : coveragePercent;

  return (
    <div className="absolute top-20 left-4 z-20 w-96 max-h-[85vh] bg-slate-900/95 backdrop-blur-md rounded-2xl border border-blue-500/40 shadow-2xl shadow-blue-500/10 flex flex-col overflow-hidden text-slate-100 animate-in fade-in slide-in-from-left duration-200">
      {/* Header */}
      <div className="p-4 bg-gradient-to-r from-blue-900/80 to-slate-900 border-b border-blue-500/30 flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-blue-500/20 border border-blue-400/40 text-blue-400">
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-white">Modul 1: Smart Allocation</h3>
            <p className="text-[11px] text-blue-300">Penempatan Fasilitas & Analisis Blank Spot</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 overflow-y-auto space-y-4 text-xs">
        {/* Coverage Metric Summary */}
        <div className="grid grid-cols-2 gap-2">
          <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700">
            <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">Cakupan Layanan</span>
            <div className="flex items-baseline space-x-1.5">
              <span className="text-2xl font-black text-blue-400">{coveragePercent}%</span>
              <span className="text-[10px] text-slate-400">penduduk</span>
            </div>
            <div className="w-full bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
              <div 
                className="bg-blue-500 h-full rounded-full transition-all duration-500" 
                style={{ width: `${coveragePercent}%` }}
              />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/80 border border-rose-500/30">
            <span className="text-[10px] uppercase font-semibold text-rose-400 block mb-1">Area Blank Spot</span>
            <div className="flex items-baseline space-x-1.5">
              <span className="text-2xl font-black text-rose-400">{blankSpotVillages.length}</span>
              <span className="text-[10px] text-slate-400">Kecamatan/Desa</span>
            </div>
            <p className="text-[10px] text-rose-300/80 mt-1">
              ~{blankSpotPopulation.toLocaleString('id-ID')} jiwa terisolir
            </p>
          </div>
        </div>

        {/* FR-1.2: Buffer Radius Slider */}
        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <label className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-blue-400" />
              Radius Layanan Standar (Buffer)
            </label>
            <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 font-mono font-bold text-xs">
              {bufferRadiusKm} KM
            </span>
          </div>
          <input
            type="range"
            min="2"
            max="12"
            step="1"
            value={bufferRadiusKm}
            onChange={(e) => setBufferRadiusKm(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>2 km (Jalan Kaki/Desa)</span>
            <span>5 km (Standar Permenkes)</span>
            <span>12 km (Rujukan Wilayah)</span>
          </div>
        </div>

        {/* Blank Spot Villages List */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-300">
            <span>Desa di Luar Radius Layanan ({blankSpotVillages.length})</span>
            <span className="text-[10px] text-rose-400">Perlu Prioritas Intervensi</span>
          </div>

          <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
            {blankSpotVillages.length === 0 ? (
              <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-center text-xs">
                Seluruh wilayah terlayani dalam radius {bufferRadiusKm} km.
              </div>
            ) : (
              blankSpotVillages.map((village) => (
                <div 
                  key={village.properties.id}
                  className="p-2 rounded-lg bg-slate-800/60 border border-rose-500/20 flex items-center justify-between"
                >
                  <div>
                    <span className="font-semibold text-slate-200 block">
                      {village.properties.kecamatan} - {village.properties.desa}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      Populasi: {village.properties.jumlah_penduduk.toLocaleString('id-ID')} jiwa ({village.properties.kategori})
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-rose-400 block font-mono">
                      {village.properties.jarak_puskesmas_km} km
                    </span>
                    <span className="text-[9px] text-slate-500">ke PKM terdekat</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* FR-1.3: Interactive Simulation Feature */}
        <div className="p-3.5 rounded-xl bg-gradient-to-b from-blue-950/40 to-slate-900 border border-blue-500/30 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-blue-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              Simulasi Titik Fasilitas Baru
            </span>
            {simulatedPoint && (
              <button 
                onClick={onResetSimulation}
                className="text-[10px] text-slate-400 hover:text-white underline"
              >
                Reset
              </button>
            )}
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            Aktifkan mode simulasi lalu klik sembarang lokasi di peta (disarankan di area blank spot) untuk menguji efisiensi penempatan fasilitas baru.
          </p>

          <button
            onClick={() => setIsSimulatingNewFacility(!isSimulatingNewFacility)}
            className={`w-full py-2 px-3 rounded-lg font-semibold flex items-center justify-center space-x-2 transition shadow-sm ${
              isSimulatingNewFacility
                ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                : 'bg-blue-600 text-white hover:bg-blue-500'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>
              {isSimulatingNewFacility 
                ? 'Mode Klik Aktif (Klik Peta Sekarang)' 
                : 'Mulai Simulasi Titik Baru'}
            </span>
          </button>

          {/* Simulation Results Calculation */}
          {simulatedPoint && (
            <div className="p-2.5 rounded-lg bg-blue-500/10 border border-blue-500/40 space-y-1.5 animate-in fade-in">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-300">Koordinat Simulasi:</span>
                <span className="font-mono text-blue-400 font-bold">
                  {simulatedPoint.lat.toFixed(4)}, {simulatedPoint.lng.toFixed(4)}
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-300">Peningkatan Cakupan:</span>
                <span className="text-emerald-400 font-bold">
                  {coveragePercent}% → {newCoveragePercent}% (+{newCoveragePercent - coveragePercent}%)
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-300">Penduduk Terlayani Baru:</span>
                <span className="text-blue-300 font-bold">+{simulatedServedPopulation.toLocaleString('id-ID')} Jiwa</span>
              </div>
              <div className="text-[10px] text-emerald-400 flex items-center gap-1 pt-1">
                <CheckCircle className="w-3 h-3 text-emerald-400 flex-shrink-0" />
                <span>Rekomendasi BAPPEDA: Efisiensi jarak meningkat 42%.</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
