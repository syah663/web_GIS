import React, { useState } from 'react';
import { Layers, Eye, EyeOff, Map, Info, ChevronDown, ChevronUp } from 'lucide-react';
import { TILE_PROVIDERS } from '../data/spatialData';

export default function LayerControlPanel({
  activeLayers,
  toggleLayer,
  currentTile,
  setCurrentTile,
  isPublicMode
}) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [showLegend, setShowLegend] = useState(true);

  return (
    <div className="absolute top-20 right-4 z-20 w-72 flex flex-col space-y-2 pointer-events-auto">
      {/* Layer Switcher Card */}
      <div className="bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-700/80 shadow-2xl overflow-hidden transition-all duration-300">
        <div 
          onClick={() => setIsExpanded(!isExpanded)}
          className="px-3.5 py-2.5 bg-slate-800/80 border-b border-slate-700/60 flex items-center justify-between cursor-pointer hover:bg-slate-800 select-none"
        >
          <div className="flex items-center space-x-2 text-slate-200">
            <Layers className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-semibold uppercase tracking-wider">Kontrol Layer & Basemap</span>
          </div>
          {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
        </div>

        {isExpanded && (
          <div className="p-3.5 space-y-3.5 text-xs">
            {/* Basemap Selection */}
            <div>
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5 flex items-center gap-1">
                <Map className="w-3 h-3 text-slate-400" /> Tipe Peta Dasar
              </label>
              <select
                value={currentTile}
                onChange={(e) => setCurrentTile(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-200 text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              >
                {Object.entries(TILE_PROVIDERS).map(([key, provider]) => (
                  <option key={key} value={key}>
                    {provider.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Layer Toggles */}
            <div className="space-y-1.5 border-t border-slate-800 pt-2.5">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Layer Tematik Spasial
              </label>

              {/* Batas Administrasi */}
              <button
                onClick={() => toggleLayer('boundaries')}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg border transition ${
                  activeLayers.boundaries 
                    ? 'bg-slate-800/90 border-emerald-500/50 text-white' 
                    : 'bg-slate-950/50 border-slate-800 text-slate-400'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span className="w-3 h-3 rounded-sm border border-emerald-400 bg-emerald-500/20" />
                  <span>Batas Administrasi Desa</span>
                </div>
                {activeLayers.boundaries ? <Eye className="w-3.5 h-3.5 text-emerald-400" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>

              {/* Heatmap Demografi */}
              <button
                onClick={() => toggleLayer('demographyHeat')}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg border transition ${
                  activeLayers.demographyHeat 
                    ? 'bg-slate-800/90 border-blue-500/50 text-white' 
                    : 'bg-slate-950/50 border-slate-800 text-slate-400'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span className="w-3 h-3 rounded-full bg-gradient-to-r from-cyan-400 to-blue-600" />
                  <span>Kepadatan Penduduk (Heatmap)</span>
                </div>
                {activeLayers.demographyHeat ? <Eye className="w-3.5 h-3.5 text-blue-400" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>

              {/* Zonasi Kerawanan Bencana (Safety Filter) */}
              <button
                onClick={() => toggleLayer('hazard')}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg border transition ${
                  activeLayers.hazard 
                    ? 'bg-slate-800/90 border-rose-500/50 text-white' 
                    : 'bg-slate-950/50 border-slate-800 text-slate-400'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span className="w-3 h-3 rounded-sm bg-rose-500/60 border border-rose-400" />
                  <span className="font-medium text-rose-300">Zonasi Bencana Longsor</span>
                </div>
                {activeLayers.hazard ? <Eye className="w-3.5 h-3.5 text-rose-400" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>

              {/* Fasilitas Publik */}
              <button
                onClick={() => toggleLayer('facilities')}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg border transition ${
                  activeLayers.facilities 
                    ? 'bg-slate-800/90 border-teal-500/50 text-white' 
                    : 'bg-slate-950/50 border-slate-800 text-slate-400'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span className="w-3 h-3 rounded-full bg-teal-400 ring-2 ring-teal-500/30" />
                  <span>Fasilitas Publik (Puskesmas/RS)</span>
                </div>
                {activeLayers.facilities ? <Eye className="w-3.5 h-3.5 text-teal-400" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>

              {/* Sentra Ekonomi UMKM */}
              <button
                onClick={() => toggleLayer('economic')}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg border transition ${
                  activeLayers.economic 
                    ? 'bg-slate-800/90 border-amber-500/50 text-white' 
                    : 'bg-slate-950/50 border-slate-800 text-slate-400'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span className="w-3 h-3 rounded-full bg-amber-400 ring-2 ring-amber-500/30" />
                  <span>Sentra UMKM & Kopi</span>
                </div>
                {activeLayers.economic ? <Eye className="w-3.5 h-3.5 text-amber-400" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>

              {/* Koridor Jalan Arteri */}
              <button
                onClick={() => toggleLayer('roads')}
                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg border transition ${
                  activeLayers.roads 
                    ? 'bg-slate-800/90 border-orange-500/50 text-white' 
                    : 'bg-slate-950/50 border-slate-800 text-slate-400'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span className="w-4 h-1 rounded bg-orange-400" />
                  <span>Jalan Arteri Provinsi</span>
                </div>
                {activeLayers.roads ? <Eye className="w-3.5 h-3.5 text-orange-400" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Legenda Bencana */}
      <div className="bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-700/80 shadow-2xl overflow-hidden">
        <div 
          onClick={() => setShowLegend(!showLegend)}
          className="px-3.5 py-2 bg-slate-800/80 border-b border-slate-700/60 flex items-center justify-between cursor-pointer hover:bg-slate-800 select-none"
        >
          <div className="flex items-center space-x-2 text-slate-300">
            <Info className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px] font-semibold uppercase tracking-wider">Legenda Zonasi Bencana</span>
          </div>
          {showLegend ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
        </div>

        {showLegend && (
          <div className="p-3 space-y-2 text-[11px] text-slate-300">
            <div className="flex items-start space-x-2">
              <span className="w-3.5 h-3.5 mt-0.5 rounded-sm bg-rose-500/70 border border-rose-400 flex-shrink-0" />
              <div>
                <span className="font-semibold text-rose-400 block">Zona Merah (Bahaya Ekstrem)</span>
                <span className="text-[10px] text-slate-400">Lereng &gt;40%, rawan longsor aktif. Kunci mati izin rekomendasi.</span>
              </div>
            </div>

            <div className="flex items-start space-x-2">
              <span className="w-3.5 h-3.5 mt-0.5 rounded-sm bg-amber-500/60 border border-amber-400 flex-shrink-0" />
              <div>
                <span className="font-semibold text-amber-300 block">Zona Kuning (Rawan Sedang)</span>
                <span className="text-[10px] text-slate-400">Lereng 15-40%. Diizinkan bersyarat (wajib talud & bronjong).</span>
              </div>
            </div>

            <div className="flex items-start space-x-2">
              <span className="w-3.5 h-3.5 mt-0.5 rounded-sm bg-emerald-500/50 border border-emerald-400 flex-shrink-0" />
              <div>
                <span className="font-semibold text-emerald-400 block">Zona Hijau (Aman / Layak Bangun)</span>
                <span className="text-[10px] text-slate-400">Lembah datar &lt;15%. Prioritas alokasi fasilitas publik & perumahan.</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
