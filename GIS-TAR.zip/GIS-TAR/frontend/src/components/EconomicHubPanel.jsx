import React, { useState } from 'react';
import { 
  TrendingUp, 
  Coffee, 
  Scissors, 
  Car, 
  Warehouse, 
  Sparkles, 
  CheckCircle, 
  Route, 
  MapPin, 
  X,
  ExternalLink
} from 'lucide-react';
import { economicHubs } from '../data/spatialData';

export default function EconomicHubPanel({ onClose, onSelectHub, selectedHub }) {
  const [activeFilter, setActiveFilter] = useState('all');

  const hubs = economicHubs.features.filter(f => f.geometry.type === 'Point');
  const roads = economicHubs.features.filter(f => f.geometry.type === 'LineString');

  const filteredHubs = activeFilter === 'all' 
    ? hubs 
    : hubs.filter(h => h.properties.sektor.toLowerCase().includes(activeFilter.toLowerCase()));

  // Logistics Hub Recommendation feature (Sumarorong)
  const logisticsHub = hubs.find(h => h.properties.id === 'ECO-05');

  return (
    <div className="absolute top-20 left-4 z-20 w-96 max-h-[85vh] bg-slate-900/95 backdrop-blur-md rounded-2xl border border-amber-500/40 shadow-2xl shadow-amber-500/10 flex flex-col overflow-hidden text-slate-100 animate-in fade-in slide-in-from-left duration-200">
      {/* Header */}
      <div className="p-4 bg-gradient-to-r from-amber-950/80 to-slate-900 border-b border-amber-500/30 flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-400">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-white">Modul 3: Economic Hub</h3>
            <p className="text-[11px] text-amber-300">Sentra UMKM Kopi, Tenun & Koridor Logistik</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 overflow-y-auto space-y-4 text-xs">
        {/* Commodity Filter Tabs */}
        <div className="flex space-x-1 p-1 bg-slate-950 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveFilter('all')}
            className={`flex-1 py-1 rounded-lg text-[11px] font-medium transition ${
              activeFilter === 'all' ? 'bg-amber-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Semua
          </button>
          <button
            onClick={() => setActiveFilter('kopi')}
            className={`flex-1 py-1 rounded-lg text-[11px] font-medium transition flex items-center justify-center gap-1 ${
              activeFilter === 'kopi' ? 'bg-amber-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Coffee className="w-3 h-3" /> Kopi
          </button>
          <button
            onClick={() => setActiveFilter('tenun')}
            className={`flex-1 py-1 rounded-lg text-[11px] font-medium transition flex items-center justify-center gap-1 ${
              activeFilter === 'tenun' ? 'bg-amber-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Scissors className="w-3 h-3" /> Tenun
          </button>
          <button
            onClick={() => setActiveFilter('pergudangan')}
            className={`flex-1 py-1 rounded-lg text-[11px] font-medium transition flex items-center justify-center gap-1 ${
              activeFilter === 'pergudangan' ? 'bg-amber-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Warehouse className="w-3 h-3" /> Logistik
          </button>
        </div>

        {/* FR-3.2: Recommended Logistics Hub Feature */}
        {logisticsHub && (
          <div className="p-3.5 rounded-xl bg-gradient-to-br from-amber-500/10 via-slate-900 to-slate-950 border border-amber-500/40 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Rekomendasi Sentra Logistik Mamasa
              </span>
              <span className="px-1.5 py-0.5 rounded text-[9px] bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                KSK Strategis
              </span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              <strong>{logisticsHub.properties.nama}</strong>: Teridentifikasi sebagai simpul optimal jarak terpendek konsolidasi kopi hulu pegunungan ke koridor hilir Sulbar-Sulsel dan Bandara Sumarorong.
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div className="p-2 rounded-lg bg-slate-800/80 border border-slate-700">
                <span className="text-[9px] text-slate-400 block">Jarak ke Jalan Provinsi</span>
                <span className="text-sm font-black text-amber-400">{logisticsHub.properties.jarak_ke_jalan_provinsi_km} km</span>
              </div>
              <div className="p-2 rounded-lg bg-slate-800/80 border border-slate-700">
                <span className="text-[9px] text-slate-400 block">Kapasitas Gudang</span>
                <span className="text-sm font-black text-amber-400">{logisticsHub.properties.kapasitas_ton_tahun} Ton/Thn</span>
              </div>
            </div>
            <button
              onClick={() => onSelectHub && onSelectHub(logisticsHub)}
              className="w-full py-1.5 px-2.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-lg transition text-[11px] flex items-center justify-center gap-1"
            >
              <MapPin className="w-3.5 h-3.5" /> Fokuskan Titik Logistik di Peta
            </button>
          </div>
        )}

        {/* List of MSME Clusters */}
        <div className="space-y-2">
          <span className="font-semibold text-slate-300 block text-[11px]">
            Sebaran Titik Sentra Komoditas ({filteredHubs.length})
          </span>

          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {filteredHubs.map((hub) => (
              <div
                key={hub.properties.id}
                onClick={() => onSelectHub && onSelectHub(hub)}
                className={`p-3 rounded-xl border cursor-pointer transition ${
                  selectedHub?.properties?.id === hub.properties.id
                    ? 'bg-amber-500/20 border-amber-400 text-white'
                    : 'bg-slate-800/60 border-slate-700/80 text-slate-200 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-xs text-amber-300">{hub.properties.nama}</h4>
                    <span className="text-[10px] text-slate-400 block">{hub.properties.komoditas}</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 font-mono text-slate-300 border border-slate-700">
                    {hub.properties.kapasitas_ton_tahun} Ton
                  </span>
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2 pt-2 border-t border-slate-700/50">
                  <span className="flex items-center gap-1">
                    <Route className="w-3 h-3 text-orange-400" />
                    Jarak ke Jalan Poros: <strong className="text-slate-200">{hub.properties.jarak_ke_jalan_provinsi_km} km</strong>
                  </span>
                  <span className="text-emerald-400 font-medium">
                    {hub.properties.status_sertifikasi}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
