import React from 'react';
import { 
  ShieldAlert, 
  MapPin, 
  TrendingUp, 
  Layers, 
  BarChart3, 
  Users, 
  Building2, 
  FileText,
  Sliders,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

export default function Navbar({ 
  currentMode, 
  setCurrentMode, 
  currentRole, 
  setCurrentRole, 
  activeModule, 
  setActiveModule,
  activeLayers,
  setActiveLayers
}) {
  const roles = [
    { id: 'bappeda', label: 'BAPPEDA (Planner)', icon: Building2, color: 'bg-blue-600' },
    { id: 'pupr', label: 'Dinas PUPR (Validator Izin)', icon: CheckCircle2, color: 'bg-emerald-600' },
    { id: 'bpbd', label: 'BPBD (Mitigasi Bencana)', icon: AlertTriangle, color: 'bg-amber-600' },
    { id: 'bupati', label: 'Bupati / Eksekutif', icon: Users, color: 'bg-purple-600' }
  ];

  return (
    <header className="h-16 bg-slate-900/95 backdrop-blur border-b border-slate-800 px-4 flex items-center justify-between z-30 relative select-none">
      {/* Brand & Logo */}
      <div className="flex items-center space-x-3">
        <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-green-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-white font-black text-xl">
          ST
        </div>
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="font-bold text-base tracking-tight text-white flex items-center gap-1.5">
              SIG-TAR MAMASA
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono border border-emerald-500/30">
                v1.0 PRD
              </span>
            </h1>
          </div>
          <p className="text-xs text-slate-400 hidden sm:block">
            Sistem Informasi Geografis Tata Ruang & Mitigasi Risiko Bencana Kab. Mamasa
          </p>
        </div>
      </div>

      {/* Center Navigation Modules */}
      <div className="flex items-center space-x-1 bg-slate-800/80 p-1 rounded-lg border border-slate-700/80">
        <button
          onClick={() => setActiveModule(activeModule === 'allocation' ? null : 'allocation')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition ${
            activeModule === 'allocation'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
          }`}
          title="Modul 1: Alokasi Cerdas Fasilitas & Analisis Blank Spot"
        >
          <MapPin className="w-3.5 h-3.5 text-blue-400" />
          <span className="hidden md:inline">1. Smart Allocation</span>
          <span className="md:hidden">Alokasi</span>
        </button>

        <button
          onClick={() => setActiveModule(activeModule === 'safety' ? null : 'safety')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition ${
            activeModule === 'safety'
              ? 'bg-rose-600 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
          }`}
          title="Modul 2: Screening Koordinat Rawan Bencana & Rekomendasi Titik Aman"
        >
          <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
          <span className="hidden md:inline">2. Safety Filter</span>
          <span className="md:hidden">Screening</span>
        </button>

        <button
          onClick={() => setActiveModule(activeModule === 'economic' ? null : 'economic')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition ${
            activeModule === 'economic'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
          }`}
          title="Modul 3: Sentra UMKM Kopi/Tenun & Koridor Logistik"
        >
          <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden md:inline">3. Economic Hub</span>
          <span className="md:hidden">Ekonomi</span>
        </button>

        <button
          onClick={() => setActiveModule(activeModule === 'executive' ? null : 'executive')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition ${
            activeModule === 'executive'
              ? 'bg-purple-600 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
          }`}
          title="Modul 4: Dasbor Eksekutif & Riwayat Perizinan"
        >
          <BarChart3 className="w-3.5 h-3.5 text-purple-400" />
          <span className="hidden md:inline">4. Dasbor & Laporan</span>
          <span className="md:hidden">Dasbor</span>
        </button>
      </div>

      {/* Right: Dual Portal Toggle & RBAC Selector */}
      <div className="flex items-center space-x-3">
        {/* Mode Switcher: Publik vs Internal */}
        <div className="flex items-center bg-slate-950 p-0.5 rounded-lg border border-slate-800">
          <button
            onClick={() => setCurrentMode('public')}
            className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
              currentMode === 'public'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Portal Publik
          </button>
          <button
            onClick={() => setCurrentMode('internal')}
            className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
              currentMode === 'internal'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Portal Internal
          </button>
        </div>

        {/* Role Selector (visible in internal mode) */}
        {currentMode === 'internal' && (
          <select
            value={currentRole}
            onChange={(e) => setCurrentRole(e.target.value)}
            className="bg-slate-800 text-xs text-slate-200 border border-slate-700 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          >
            {roles.map((r) => (
              <option key={r.id} value={r.id}>
                {r.label}
              </option>
            ))}
          </select>
        )}
      </div>
    </header>
  );
}
