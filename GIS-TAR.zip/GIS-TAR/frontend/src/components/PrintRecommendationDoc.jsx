import React from 'react';
import { Printer, X, ShieldAlert, CheckCircle2, AlertTriangle, QrCode } from 'lucide-react';

export default function PrintRecommendationDoc({ data, onClose }) {
  if (!data) return null;

  const handlePrint = () => {
    window.print();
  };

  const isRed = data.hasil_zona === 'merah';
  const isYellow = data.hasil_zona === 'kuning';
  const isGreen = data.hasil_zona === 'hijau';

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      {/* Container Dialog */}
      <div className="w-full max-w-3xl bg-white text-slate-900 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Top Control Bar (Hidden on print) */}
        <div className="px-6 py-3 bg-slate-900 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center space-x-2">
            <Printer className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold uppercase tracking-wider">
              Pratinjau Dokumen Rekomendasi Teknis Tata Ruang (Siap Cetak / PDF)
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition shadow"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak / Simpan ke PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Paper Canvas */}
        <div id="printable-document" className="p-10 font-serif leading-relaxed text-sm bg-white text-black">
          {/* Kop Surat Resmi Pemkab Mamasa */}
          <div className="border-b-4 border-double border-slate-900 pb-4 text-center">
            <h3 className="font-bold tracking-wider text-base uppercase">PEMERINTAH KABUPATEN MAMASA</h3>
            <h2 className="font-black tracking-wide text-lg uppercase text-slate-900">
              BADAN PERENCANAAN PEMBANGUNAN DAERAH (BAPPEDA)
            </h2>
            <h2 className="font-bold text-base uppercase text-slate-800">
              DINAS PEKERJAAN UMUM DAN PENATAAN RUANG (PUPR)
            </h2>
            <p className="font-sans text-[11px] text-slate-600 mt-1">
              Kompleks Perkantoran Gabungan Dinas Rante-Rante, Mamasa, Sulawesi Barat &bull; Kode Pos 91362
            </p>
          </div>

          {/* Judul Surat */}
          <div className="text-center my-6">
            <h4 className="font-bold underline text-sm tracking-wide uppercase">
              SURAT KEPUTUSAN REKOMENDASI TEKNIS KESESUAIAN TATA RUANG
            </h4>
            <p className="font-sans text-xs text-slate-600 mt-0.5">
              Nomor Registrasi Sistem: <strong>{data.nomor_registrasi || 'REG-MMS-2026-001'}</strong>
            </p>
          </div>

          {/* Rincian Permohonan */}
          <div className="space-y-4 text-xs font-sans">
            <p>
              Berdasarkan hasil analisis otomatis Sistem Informasi Geografis Tata Ruang (<strong>SIG-TAR Mamasa</strong>) terhadap permohonan kesesuaian ruang wilayah berikut:
            </p>

            <table className="w-full border-collapse">
              <tbody>
                <tr className="border-b border-slate-200">
                  <td className="py-1.5 font-bold w-48 text-slate-700">Nama Pemohon / Instansi</td>
                  <td className="py-1.5">: {data.nama_pemohon || 'PT. Sulawesi Agro Mandiri'}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="py-1.5 font-bold text-slate-700">Rencana Kegiatan / Proyek</td>
                  <td className="py-1.5">: {data.nama_proyek || 'Pembangunan Gudang & Fasilitas Komersial'}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="py-1.5 font-bold text-slate-700">Kategori Pemanfaatan Ruang</td>
                  <td className="py-1.5">: {data.jenis_kegiatan || 'Bangunan Gedung / Komersial'}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="py-1.5 font-bold text-slate-700">Koordinat Lokasi Diajukan</td>
                  <td className="py-1.5 font-mono">: Lintang {data.latitude?.toFixed(6) || '-2.942000'}, Bujur {data.longitude?.toFixed(6) || '119.395000'}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="py-1.5 font-bold text-slate-700">Klasifikasi Zonasi Bencana</td>
                  <td className="py-1.5">
                    : <strong className={isRed ? 'text-red-700 uppercase' : isYellow ? 'text-amber-700 uppercase' : 'text-green-700 uppercase'}>
                      ZONA {data.hasil_zona?.toUpperCase() || 'MERAH'} (Peta Kerawanan Longsor Mamasa)
                    </strong>
                  </td>
                </tr>
              </tbody>
            </table>

            {/* Kotak Keputusan Status Rekomendasi */}
            <div className={`p-4 rounded-lg border-2 my-4 ${
              isRed 
                ? 'border-red-600 bg-red-50 text-red-950' 
                : isYellow 
                ? 'border-amber-600 bg-amber-50 text-amber-950' 
                : 'border-green-600 bg-green-50 text-green-950'
            }`}>
              <div className="flex items-center space-x-2 font-bold text-sm mb-1 uppercase">
                {isRed && <ShieldAlert className="w-5 h-5 text-red-600" />}
                {isYellow && <AlertTriangle className="w-5 h-5 text-amber-600" />}
                {isGreen && <CheckCircle2 className="w-5 h-5 text-green-600" />}
                <span>
                  KEPUTUSAN: {data.status_rekomendasi ? data.status_rekomendasi.replace('_', ' ') : 'DITOLAK KARENA BAHAYA BENCANA'}
                </span>
              </div>
              <p className="text-xs leading-relaxed">
                {data.catatan_teknis || 'Lokasi berada di lereng terjal >45% dengan potensi pergerakan tanah aktif. Berdasarkan RTRW Kabupaten Mamasa Pasal 42, kawasan ini mutlak berfungsi lindung dan dilarang untuk pembangunan fisik baru demi keselamatan jiwa.'}
              </p>

              {/* Titik Alternatif Jika Zona Merah */}
              {isRed && data.titik_alternatif_lat && (
                <div className="mt-3 pt-2 border-t border-red-300 text-xs">
                  <strong>SARAN SOLUSI TATA RUANG:</strong> Pemohon diarahkan memindahkan rencana kegiatan ke Zona Hijau terdekat pada koordinat <strong>{data.titik_alternatif_lat.toFixed(6)}, {data.titik_alternatif_lng.toFixed(6)}</strong> (Jarak: ~{data.jarak_titik_alternatif_meter || 3400} meter di Lembah Mamasa).
                </div>
              )}
            </div>

            <p className="text-[11px] text-slate-600 italic">
              Dokumen ini diterbitkan secara otomatis dan sah secara hukum melalui Sistem Informasi Geografis Tata Ruang Kabupaten Mamasa berlandaskan Perda RTRW Kabupaten Mamasa No. 12 Tahun 2021.
            </p>

            {/* Tanda Tangan & QR Code */}
            <div className="pt-8 flex items-end justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-20 h-20 border border-slate-300 p-1 flex items-center justify-center bg-slate-50">
                  <QrCode className="w-16 h-16 text-slate-800" />
                </div>
                <div className="text-[10px] text-slate-500 font-sans max-w-[200px]">
                  Pindai QR untuk validasi keaslian dokumen pada server resmi SIG-TAR Pemkab Mamasa.
                </div>
              </div>

              <div className="text-center w-64">
                <p className="text-xs text-slate-700">Mamasa, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                <p className="text-xs font-bold text-slate-900 mt-1">Kepala Dinas PUPR / BAPPEDA</p>
                <p className="text-xs text-slate-800">Kabupaten Mamasa</p>
                <div className="h-14 flex items-center justify-center">
                  <span className="text-[10px] font-mono tracking-widest text-emerald-800 border border-emerald-600 px-3 py-1 rounded rotate-[-5deg] font-bold">
                    [ TERTANDA DIGITAL RESMI ]
                  </span>
                </div>
                <p className="text-xs font-bold underline text-slate-900">TIM VERIFIKATOR TATA RUANG</p>
                <p className="text-[10px] text-slate-600 font-mono">NIP. 19780514 200502 1 003</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
