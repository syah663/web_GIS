import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  ShieldCheck, 
  ShieldAlert, 
  Clock, 
  CheckCircle2, 
  FileText, 
  Printer, 
  Upload, 
  Users, 
  TrendingUp,
  X,
  FileCheck
} from 'lucide-react';

export default function ExecutiveDashboardModal({ 
  onClose, 
  onOpenDocModal, 
  setSelectedScreeningForDoc 
}) {
  const [activeTab, setActiveTab] = useState('overview'); // overview, log, upload
  const [screenings, setScreenings] = useState([
    {
      id: 101,
      nomor_registrasi: 'REG-MMS-2026-001',
      nama_pemohon: 'PT. Sulawesi Agro Mandiri',
      nama_proyek: 'Pembangunan Gudang Pengolahan Kopi & Villa Agrowisata',
      jenis_kegiatan: 'Komersial / Pergudangan',
      latitude: -2.942,
      longitude: 119.395,
      hasil_zona: 'merah',
      status_rekomendasi: 'DITOLAK_BAHAYA',
      titik_alternatif_lat: -2.952,
      titik_alternatif_lng: 119.365,
      jarak_titik_alternatif_meter: 3400,
      catatan_teknis: 'Lokasi berada di lereng terjal >45% dengan potensi longsor aktif. Rekomendasi dialihkan ke Zona Hijau Lembah Mamasa.',
      validator_nama: 'Dinas PUPR Mamasa',
      created_at: '2026-09-10 14:20:00'
    },
    {
      id: 102,
      nomor_registrasi: 'REG-MMS-2026-002',
      nama_pemohon: 'Dinas Kesehatan Prov. Sulawesi Barat',
      nama_proyek: 'Pembangunan Pustu Terpadu Minake',
      jenis_kegiatan: 'Fasilitas Kesehatan Publik',
      latitude: -3.010,
      longitude: 119.340,
      hasil_zona: 'kuning',
      status_rekomendasi: 'DISETUJUI_BERSYARAT',
      titik_alternatif_lat: null,
      titik_alternatif_lng: null,
      jarak_titik_alternatif_meter: null,
      catatan_teknis: 'Zona Kuning (Kemiringan 20%). Disetujui dengan syarat wajib membuat retaining wall / talud beton bertulang.',
      validator_nama: 'Dinas PUPR Mamasa',
      created_at: '2026-09-11 09:15:00'
    },
    {
      id: 103,
      nomor_registrasi: 'REG-MMS-2026-003',
      nama_pemohon: 'Koperasi Tani Kopi Mambulilling',
      nama_proyek: 'Gudang Konsolidasi Logistik Sumarorong',
      jenis_kegiatan: 'Pusat Logistik Pertanian',
      latitude: -3.070,
      longitude: 119.325,
      hasil_zona: 'hijau',
      status_rekomendasi: 'DISETUJUI_AMAN',
      titik_alternatif_lat: null,
      titik_alternatif_lng: null,
      jarak_titik_alternatif_meter: null,
      catatan_teknis: 'Kawasan datar Sumarorong, bebas banjir dan longsor, akses langsung ke jalan arteri provinsi.',
      validator_nama: 'BAPPEDA Kab. Mamasa',
      created_at: '2026-09-12 11:30:00'
    }
  ]);

  const [stats, setStats] = useState({
    total_screening: 48,
    merah_ditolak: 14,
    kuning_bersyarat: 19,
    hijau_disetujui: 15,
    rasio_keamanan_persen: 100.0,
    blank_spot_desa_terdeteksi: 3,
    estimasi_populasi_blank_spot: 21110
  });

  // Upload simulation
  const [uploadStatus, setUploadStatus] = useState(null);

  const handlePrintItem = (item) => {
    setSelectedScreeningForDoc(item);
    onOpenDocModal();
  };

  const handleFileUpload = (e) => {
    e.preventDefault();
    setUploadStatus('Memvalidasi geometri spasial & sinkronisasi data cPanel...');
    setTimeout(() => {
      setUploadStatus('Data spasial berhasil diperbarui (12 fitur GeoJSON terindeks)');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-slate-100">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <BarChart3 className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Dasbor Eksekutif & Manajemen Tata Ruang
                <span className="text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-normal">
                  Bupati & Kepala Dinas
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Pemerintah Kabupaten Mamasa &mdash; Pemantauan Kesesuaian Tata Ruang & Risiko Bencana
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Tabs */}
            <div className="flex bg-slate-800 p-1 rounded-lg text-xs">
              <button
                onClick={() => setActiveTab('overview')}
                className={`px-3 py-1 rounded-md font-medium transition ${
                  activeTab === 'overview' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Ringkasan Metrik
              </button>
              <button
                onClick={() => setActiveTab('log')}
                className={`px-3 py-1 rounded-md font-medium transition ${
                  activeTab === 'log' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Log Screening ({screenings.length})
              </button>
              <button
                onClick={() => setActiveTab('upload')}
                className={`px-3 py-1 rounded-md font-medium transition ${
                  activeTab === 'upload' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Upload Data Spasial
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* TAB 1: OVERVIEW METRICS */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Success Metrics Banner (PRD Section 6) */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-950/60 to-slate-900 border border-emerald-500/40">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold uppercase text-emerald-400">Akurasi Keamanan Bencana</span>
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div className="text-3xl font-black text-white">100%</div>
                  <p className="text-[11px] text-emerald-300 mt-1">
                    <strong>Nol (0)</strong> izin diterbitkan di Zona Merah pasca implementasi SIG-TAR Mamasa.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-gradient-to-br from-blue-950/60 to-slate-900 border border-blue-500/40">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold uppercase text-blue-400">Efisiensi Waktu Analisis</span>
                    <Clock className="w-5 h-5 text-blue-400" />
                  </div>
                  <div className="text-3xl font-black text-white">&lt; 1 Menit</div>
                  <p className="text-[11px] text-blue-300 mt-1">
                    Memangkas waktu survei lapangan dari hitungan minggu menjadi komputasi instan.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-gradient-to-br from-purple-950/60 to-slate-900 border border-purple-500/40">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold uppercase text-purple-400">Total Proyek Di-Screening</span>
                    <FileCheck className="w-5 h-5 text-purple-400" />
                  </div>
                  <div className="text-3xl font-black text-white">{stats.total_screening}</div>
                  <p className="text-[11px] text-purple-300 mt-1">
                    Pengajuan tata ruang terdaftar & tervalidasi koordinat spasial.
                  </p>
                </div>
              </div>

              {/* Status Breakdown */}
              <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                <h3 className="font-bold text-sm text-slate-200">Distribusi Hasil Validasi Tata Ruang</h3>
                <div className="grid grid-cols-3 gap-3">
                  <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300">
                    <div className="text-xs text-rose-400 font-semibold">Zona Merah (Ditolak Bahaya)</div>
                    <div className="text-2xl font-black text-rose-400 mt-1">{stats.merah_ditolak}</div>
                    <div className="text-[10px] text-rose-300/80 mt-0.5">Dikunci otomatis & diberi titik aman alternatif</div>
                  </div>

                  <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300">
                    <div className="text-xs text-amber-400 font-semibold">Zona Kuning (Disetujui Bersyarat)</div>
                    <div className="text-2xl font-black text-amber-400 mt-1">{stats.kuning_bersyarat}</div>
                    <div className="text-[10px] text-amber-300/80 mt-0.5">Wajib dinding penahan tanah & geoteknik</div>
                  </div>

                  <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
                    <div className="text-xs text-emerald-400 font-semibold">Zona Hijau (Direkomendasikan Aman)</div>
                    <div className="text-2xl font-black text-emerald-400 mt-1">{stats.hijau_disetujui}</div>
                    <div className="text-[10px] text-emerald-300/80 mt-0.5">Sesuai zonasi RT/RW Kabupaten Mamasa</div>
                  </div>
                </div>
              </div>

              {/* Blank Spot Priority Notice */}
              <div className="p-4 rounded-xl bg-blue-950/40 border border-blue-500/30 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-xs text-blue-300">Kebutuhan Alokasi Fasilitas Kesehatan (BAPPEDA Alert)</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Kecamatan <strong>Pana</strong>, <strong>Nosu</strong>, dan <strong>Tabang</strong> teridentifikasi berada di luar radius 5 km Puskesmas terdekat ({stats.estimasi_populasi_blank_spot.toLocaleString('id-ID')} jiwa).
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('log')}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition"
                >
                  Buka Detail
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: LOG SCREENINGS & CETAK SURAT REKOMENDASI */}
          {activeTab === 'log' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-400">
                  Riwayat pengajuan izin tata ruang dan verifikasi koordinat terhadap zona rawan bencana longsor.
                </p>
                <span className="text-xs text-slate-400">
                  Menampilkan {screenings.length} data terbaru
                </span>
              </div>

              <div className="border border-slate-800 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                    <tr>
                      <th className="p-3">No. Registrasi & Pemohon</th>
                      <th className="p-3">Nama Proyek</th>
                      <th className="p-3">Koordinat</th>
                      <th className="p-3">Hasil Zona</th>
                      <th className="p-3">Status</th>
                      <th className="p-3 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {screenings.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-800/50 transition">
                        <td className="p-3">
                          <span className="font-mono font-bold text-slate-200 block">{item.nomor_registrasi}</span>
                          <span className="text-[11px] text-slate-400">{item.nama_pemohon}</span>
                        </td>
                        <td className="p-3 text-slate-300 font-medium">
                          {item.nama_proyek}
                          <span className="text-[10px] text-slate-500 block">{item.jenis_kegiatan}</span>
                        </td>
                        <td className="p-3 font-mono text-[11px] text-slate-400">
                          {item.latitude.toFixed(4)}, {item.longitude.toFixed(4)}
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            item.hasil_zona === 'merah'
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              : item.hasil_zona === 'kuning'
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          }`}>
                            Zona {item.hasil_zona}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className={`font-semibold ${
                            item.status_rekomendasi === 'DITOLAK_BAHAYA' 
                              ? 'text-rose-400' 
                              : item.status_rekomendasi === 'DISETUJUI_BERSYARAT'
                              ? 'text-amber-400'
                              : 'text-emerald-400'
                          }`}>
                            {item.status_rekomendasi.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => handlePrintItem(item)}
                            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-blue-400 border border-slate-700 rounded-lg font-medium transition inline-flex items-center gap-1"
                            title="Cetak Surat Keputusan Rekomendasi Teknis"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Cetak PDF</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: UPLOAD SPATIAL DATA (FR-4.1) */}
          {activeTab === 'upload' && (
            <div className="space-y-5">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <h3 className="font-bold text-sm text-slate-200 mb-1">Pusat Manajemen Data Spasial & Non-Spasial</h3>
                <p className="text-xs text-slate-400">
                  Unggah file batas desa terbaru, peta kontur/kemiringan lereng (.geojson, .shp) atau data demografi penduduk (.xlsx/csv) untuk disinkronkan ke database MySQL cPanel.
                </p>
              </div>

              <form onSubmit={handleFileUpload} className="border-2 border-dashed border-slate-700 rounded-2xl p-8 flex flex-col items-center justify-center text-center bg-slate-950/50 hover:bg-slate-950 transition">
                <div className="p-3 rounded-full bg-purple-500/20 text-purple-400 mb-3">
                  <Upload className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-sm text-slate-200">Tarik dan Lepas File Spasial di Sini</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-sm">
                  Mendukung format <strong>.geojson</strong>, <strong>.shp (zip)</strong>, <strong>.tif (DEM Kontur)</strong>, atau <strong>.xlsx</strong> data penduduk per desa.
                </p>

                <input type="file" className="hidden" id="spatial-upload" />
                <label
                  htmlFor="spatial-upload"
                  className="mt-4 px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-semibold rounded-lg text-xs cursor-pointer transition"
                >
                  Pilih Berkas dari Komputer
                </label>
              </form>

              {uploadStatus && (
                <div className="p-3 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{uploadStatus}</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
