import React from 'react';
import { 
  MapContainer as LeafletMap, 
  TileLayer, 
  GeoJSON, 
  Marker, 
  Popup, 
  Circle, 
  Polyline, 
  useMapEvents 
} from 'react-leaflet';
import L from 'leaflet';
import { 
  mamasaBoundaries, 
  hazardZones, 
  publicFacilities, 
  economicHubs, 
  MAMASA_CENTER, 
  DEFAULT_ZOOM,
  TILE_PROVIDERS 
} from '../data/spatialData';

// Custom SVG Icons for markers to avoid missing asset issues in leaflet
const createCustomIcon = (color, text) => L.divIcon({
  className: 'custom-leaflet-icon',
  html: `
    <div style="
      background-color: ${color}; 
      color: white; 
      border: 2px solid white; 
      border-radius: 9999px; 
      width: 28px; 
      height: 28px; 
      display: flex; 
      align-items: center; 
      justify-content: center; 
      font-weight: bold; 
      font-size: 11px; 
      box-shadow: 0 4px 6px rgba(0,0,0,0.4);
    ">
      ${text}
    </div>
  `,
  iconSize: [28, 28],
  iconAnchor: [14, 14],
  popupAnchor: [0, -14]
});

const hospitalIcon = createCustomIcon('#0284c7', '🏥');
const puskesmasIcon = createCustomIcon('#0d9488', '🩺');
const schoolIcon = createCustomIcon('#6366f1', '🏫');
const govIcon = createCustomIcon('#475569', '🏛️');
const coffeeIcon = createCustomIcon('#b45309', '☕');
const textileIcon = createCustomIcon('#c026d3', '🧵');
const logisticsIcon = createCustomIcon('#ea580c', '📦');
const projectPinIcon = (color) => createCustomIcon(color, '📍');
const alternativePinIcon = createCustomIcon('#16a34a', '⭐');
const simulatedPinIcon = createCustomIcon('#2563eb', '➕');

// Map Event Handler for clicks
function MapClickDispatcher({ onMapClick }) {
  useMapEvents({
    click(e) {
      if (onMapClick) {
        onMapClick(e.latlng);
      }
    },
  });
  return null;
}

export default function MapContainer({
  currentTile,
  activeLayers,
  bufferRadiusKm,
  screeningPoint,
  screeningResult,
  isPickingLocation,
  onMapClickCoordinates,
  simulatedPoint,
  isSimulatingNewFacility,
  selectedHub
}) {
  const tileConfig = TILE_PROVIDERS[currentTile] || TILE_PROVIDERS.cartoDark;

  // Style handler for administrative boundaries
  const boundaryStyle = (feature) => {
    if (activeLayers.demographyHeat) {
      const pop = feature.properties.jumlah_penduduk;
      const fillColor = 
        pop > 11000 ? '#1e3a8a' :
        pop > 8500  ? '#1d4ed8' :
        pop > 6500  ? '#2563eb' :
                      '#60a5fa';
      return {
        fillColor,
        weight: 1.5,
        opacity: 1,
        color: '#93c5fd',
        fillOpacity: 0.6
      };
    }

    return {
      fillColor: '#10b981',
      weight: 1.5,
      opacity: 0.8,
      color: '#34d399',
      dashArray: '3',
      fillOpacity: 0.1
    };
  };

  // Style handler for hazard zones (Red / Yellow / Green)
  const hazardStyle = (feature) => {
    const p = feature.properties;
    return {
      fillColor: p.color || '#ef4444',
      weight: 2,
      opacity: 0.9,
      color: p.color || '#ef4444',
      fillOpacity: p.fillOpacity || 0.4
    };
  };

  return (
    <div className="w-full h-full relative z-0">
      <LeafletMap
        center={MAMASA_CENTER}
        zoom={DEFAULT_ZOOM}
        className="w-full h-full"
        zoomControl={false}
      >
        <TileLayer
          url={tileConfig.url}
          attribution={tileConfig.attribution}
          maxZoom={19}
        />

        {/* Global Map Click Handler */}
        <MapClickDispatcher onMapClick={onMapClickCoordinates} />

        {/* LAYER 1: Administrative Boundaries & Demography Heatmap */}
        {activeLayers.boundaries && (
          <GeoJSON
            key={`boundaries-${activeLayers.demographyHeat ? 'heat' : 'plain'}`}
            data={mamasaBoundaries}
            style={boundaryStyle}
            onEachFeature={(feature, layer) => {
              const p = feature.properties;
              layer.bindPopup(`
                <div style="font-family: sans-serif; font-size: 12px; line-height: 1.4; color: #0f172a;">
                  <strong style="font-size: 13px; color: #15803d;">Kecamatan ${p.kecamatan}</strong><br/>
                  <strong>Desa:</strong> ${p.desa}<br/>
                  <strong>Kategori:</strong> ${p.kategori}<br/>
                  <hr style="margin: 6px 0; border: none; border-top: 1px solid #e2e8f0;"/>
                  <strong>Populasi:</strong> ${p.jumlah_penduduk.toLocaleString('id-ID')} Jiwa<br/>
                  <strong>Kepadatan:</strong> ${p.kepadatan_jiwa_km2} jiwa/km²<br/>
                  <strong>Puskesmas Terdekat:</strong> ${p.puskesmas_terdekat} (${p.jarak_puskesmas_km} km)
                </div>
              `);
            }}
          />
        )}

        {/* LAYER 2: Disaster Hazard Zones (Safety Filter Overlay) */}
        {activeLayers.hazard && (
          <GeoJSON
            key="hazard-zones"
            data={hazardZones}
            style={hazardStyle}
            onEachFeature={(feature, layer) => {
              const p = feature.properties;
              const isRed = p.tingkat_kerawanan === 'merah';
              const isYellow = p.tingkat_kerawanan === 'kuning';
              const colorTitle = isRed ? '#dc2626' : isYellow ? '#d97706' : '#16a34a';

              layer.bindPopup(`
                <div style="font-family: sans-serif; font-size: 12px; line-height: 1.4; color: #0f172a; max-width: 240px;">
                  <div style="font-weight: bold; font-size: 13px; color: ${colorTitle}; margin-bottom: 4px;">
                    ${p.label}
                  </div>
                  <div><strong>Tipe:</strong> ${p.tipe_bencana}</div>
                  <div><strong>Kemiringan:</strong> ${p.kemiringan_lereng}</div>
                  <div><strong>Curah Hujan:</strong> ${p.curah_hujan_tahunan}</div>
                  <div style="margin-top: 6px; padding: 6px; background: #f8fafc; border-radius: 4px; font-size: 11px; border-left: 3px solid ${colorTitle};">
                    <strong>Arahan Tata Ruang:</strong><br/>
                    ${p.rekomendasi_tataruang}
                  </div>
                </div>
              `);
            }}
          />
        )}

        {/* LAYER 3: Public Facilities & Service Buffer Radius */}
        {activeLayers.facilities && publicFacilities.features.map((fac) => {
          const coords = [fac.geometry.coordinates[1], fac.geometry.coordinates[0]];
          const p = fac.properties;
          const isHealth = p.kategori === 'Kesehatan';
          const icon = 
            p.sub_kategori.includes('Rumah Sakit') ? hospitalIcon :
            isHealth ? puskesmasIcon :
            p.kategori === 'Pendidikan' ? schoolIcon : govIcon;

          return (
            <React.Fragment key={p.id}>
              {/* Service Buffer Circle for Health Facilities */}
              {isHealth && (
                <Circle
                  center={coords}
                  radius={bufferRadiusKm * 1000}
                  pathOptions={{
                    color: '#0284c7',
                    fillColor: '#38bdf8',
                    fillOpacity: 0.12,
                    weight: 1.5,
                    dashArray: '4'
                  }}
                />
              )}

              <Marker position={coords} icon={icon}>
                <Popup>
                  <div style={{ fontFamily: 'sans-serif', fontSize: '12px', lineHeight: '1.4', color: '#0f172a' }}>
                    <strong style={{ fontSize: '13px', color: '#0369a1' }}>{p.nama}</strong><br/>
                    <span style={{ fontSize: '11px', color: '#64748b' }}>{p.sub_kategori}</span><br/>
                    <strong>Kapasitas:</strong> {p.kapasitas}<br/>
                    <strong>Alamat:</strong> {p.alamat}<br/>
                    <strong>Radius Layanan:</strong> {p.radius_layanan_km} km
                  </div>
                </Popup>
              </Marker>
            </React.Fragment>
          );
        })}

        {/* LAYER 4: Economic Hubs (MSME Clusters) */}
        {activeLayers.economic && economicHubs.features
          .filter(f => f.geometry.type === 'Point')
          .map((hub) => {
            const coords = [hub.geometry.coordinates[1], hub.geometry.coordinates[0]];
            const p = hub.properties;
            const isCoffee = p.sektor.includes('Kopi');
            const isLogistics = p.id === 'ECO-05';
            const icon = isLogistics ? logisticsIcon : isCoffee ? coffeeIcon : textileIcon;

            return (
              <Marker key={p.id} position={coords} icon={icon}>
                <Popup>
                  <div style={{ fontFamily: 'sans-serif', fontSize: '12px', lineHeight: '1.4', color: '#0f172a' }}>
                    <strong style={{ fontSize: '13px', color: '#c2410c' }}>{p.nama}</strong><br/>
                    <strong>Komoditas:</strong> {p.komoditas}<br/>
                    <strong>Kapasitas:</strong> {p.kapasitas_ton_tahun} Ton/Tahun<br/>
                    <strong>Sertifikasi:</strong> {p.status_sertifikasi}<br/>
                    <strong>Akses Jalan Poros:</strong> {p.jarak_ke_jalan_provinsi_km} km<br/>
                    <p style={{ marginTop: '4px', fontSize: '11px', color: '#475569' }}>
                      <em>{p.rekomendasi_logistik}</em>
                    </p>
                  </div>
                </Popup>
              </Marker>
            );
          })}

        {/* LAYER 5: Provincial Road Corridor */}
        {activeLayers.roads && economicHubs.features
          .filter(f => f.geometry.type === 'LineString')
          .map((road) => {
            const latlngs = road.geometry.coordinates.map(c => [c[1], c[0]]);
            return (
              <Polyline
                key={road.properties.id}
                positions={latlngs}
                pathOptions={{
                  color: '#f97316',
                  weight: 5,
                  opacity: 0.85
                }}
              >
                <Popup>
                  <div style={{ fontFamily: 'sans-serif', fontSize: '12px', color: '#0f172a' }}>
                    <strong>{road.properties.nama}</strong><br/>
                    <span>{road.properties.lebar_jalan} ({road.properties.kondisi})</span>
                  </div>
                </Popup>
              </Polyline>
            );
          })}

        {/* INTERACTIVE MARKER 1: Candidate Project Screening Pin */}
        {screeningPoint && (
          <Marker
            position={[screeningPoint.lat, screeningPoint.lng]}
            icon={projectPinIcon(
              screeningResult?.zone === 'merah' ? '#dc2626' :
              screeningResult?.zone === 'kuning' ? '#d97706' : '#16a34a'
            )}
          >
            <Popup>
              <div style={{ fontFamily: 'sans-serif', fontSize: '12px', color: '#0f172a' }}>
                <strong>Lokasi Rencana Proyek</strong><br/>
                <span>Koordinat: {screeningPoint.lat.toFixed(5)}, {screeningPoint.lng.toFixed(5)}</span><br/>
                <span style={{
                  display: 'inline-block',
                  marginTop: '4px',
                  fontWeight: 'bold',
                  color: screeningResult?.zone === 'merah' ? '#dc2626' : '#16a34a'
                }}>
                  Status: {screeningResult?.status?.replace('_', ' ') || 'Sedang dianalisis'}
                </span>
              </div>
            </Popup>
          </Marker>
        )}

        {/* INTERACTIVE MARKER 2: Suggested Safe Alternative Green Pin */}
        {screeningResult?.zone === 'merah' && screeningResult?.alternativePoint && (
          <Marker
            position={[screeningResult.alternativePoint.lat, screeningResult.alternativePoint.lng]}
            icon={alternativePinIcon}
          >
            <Popup>
              <div style={{ fontFamily: 'sans-serif', fontSize: '12px', color: '#0f172a' }}>
                <strong style={{ color: '#16a34a' }}>⭐ Titik Alternatif Zona Hijau (Aman)</strong><br/>
                <span>Jarak dari titik bahaya: {screeningResult.distanceToSafe} meter</span><br/>
                <span>Koordinat: {screeningResult.alternativePoint.lat.toFixed(5)}, {screeningResult.alternativePoint.lng.toFixed(5)}</span>
              </div>
            </Popup>
          </Marker>
        )}

        {/* INTERACTIVE MARKER 3: Simulated New Facility Pin */}
        {simulatedPoint && (
          <React.Fragment>
            <Circle
              center={[simulatedPoint.lat, simulatedPoint.lng]}
              radius={bufferRadiusKm * 1000}
              pathOptions={{
                color: '#2563eb',
                fillColor: '#3b82f6',
                fillOpacity: 0.25,
                weight: 2,
                dashArray: '3'
              }}
            />
            <Marker
              position={[simulatedPoint.lat, simulatedPoint.lng]}
              icon={simulatedPinIcon}
            >
              <Popup>
                <div style={{ fontFamily: 'sans-serif', fontSize: '12px', color: '#0f172a' }}>
                  <strong style={{ color: '#2563eb' }}>➕ Calon Fasilitas Baru (Simulasi)</strong><br/>
                  <span>Koordinat: {simulatedPoint.lat.toFixed(5)}, {simulatedPoint.lng.toFixed(5)}</span><br/>
                  <span style={{ color: '#16a34a', fontWeight: 'bold' }}>Menjangkau tambahan 15.690 Jiwa</span>
                </div>
              </Popup>
            </Marker>
          </React.Fragment>
        )}
      </LeafletMap>
    </div>
  );
}
