// GeoJSON Data Provider for SIG-TAR Mamasa
import boundariesData from '../../../data-assets/mamasa_boundaries.json';
import hazardData from '../../../data-assets/hazard_zones.json';
import facilitiesData from '../../../data-assets/public_facilities.json';
import economicData from '../../../data-assets/economic_hubs.json';

export const mamasaBoundaries = boundariesData;
export const hazardZones = hazardData;
export const publicFacilities = facilitiesData;
export const economicHubs = economicData;

// Center of Kabupaten Mamasa
export const MAMASA_CENTER = [-2.975, 119.380];
export const DEFAULT_ZOOM = 11;

// Tile Providers
export const TILE_PROVIDERS = {
  cartoDark: {
    name: 'Peta Gelap (CartoDB Dark)',
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    attribution: '&copy; <a href="https://carto.com/">CARTO</a>'
  },
  satellite: {
    name: 'Satelit Detil (Esri World Imagery)',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
  },
  osm: {
    name: 'OpenStreetMap Standar',
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
  },
  topo: {
    name: 'Kontur Topografi (OpenTopoMap)',
    url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
    attribution: 'Kartendaten: &copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a>, SRTM | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a>'
  }
};
